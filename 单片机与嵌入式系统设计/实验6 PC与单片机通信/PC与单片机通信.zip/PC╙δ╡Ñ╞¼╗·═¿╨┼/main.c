#include<reg52.h>
#include<stdio.h>
#include<string.h>
#define uchar unsigned char
#define uint unsigned int
	
void time(uint ucms){
	uchar ucCounter;
	while(ucms!=0){
		for(ucCounter=0;ucCounter<239;ucCounter++);
		ucms--;
	}
}
void initUart(void){
	SCON=0x50;
	RCAP2H=(65536-(3456/96))>>8;
	RCAP2L=(65536-(3456/96))%256;
	T2CON=0x34;
}
void sendString(uchar *ucstr){
	uchar i,strlenth=strlen(ucstr);
	REN=0;
	for(i=0;i<strlenth;i++){
		SBUF=ucstr[i];while(TI==0);TI=0;
	}
	SBUF=0x0d;while(TI==0);TI=0;
	//SBUF=0x0a;while(TI==0);TI=0;
	//SBUF=0x0a;while(TI==0);TI=0;
	REN=1;
}


void main(){
	time(1);
	initUart();
	IE=0x90;
	while(1){
	}
}

void zhongduan(void) interrupt 4
	
{
	uchar rChar;
	uchar code str1[]="What do you plan to do on this Friday?";
	uchar code str2[]="I plan to go to the concert";
	uchar code str3[]="What are you doing next week?";
	uchar code str4[]="I'm thinking of going to my grandma's.";
	uchar code strdefault[]="Please select a character '1','2','3' or '4'!";
	
	EA=0;
	RI=0;
	rChar=SBUF;
	
	switch(rChar){
		case '1':
			P2=1;
			SBUF='1';while(TI==0);TI=0;
			SBUF=':';while(TI==0);TI=0;
			sendString(str1);
			break;
		case '2':
			P2=2;
			SBUF='2';while(TI==0);TI=0;
			SBUF=':';while(TI==0);TI=0;
			sendString(str2);
			break;
		case '3':
			P2=3;
			SBUF='3';while(TI==0);TI=0;
			SBUF=':';while(TI==0);TI=0;
			sendString(str3);
			break;
		case '4':
			P2=4;
			SBUF='4';while(TI==0);TI=0;
			SBUF=':';while(TI==0);TI=0;
			sendString(str4);
			break;
		default:
			P2=0xd;
			SBUF='d';while(TI==0);TI=0;
			SBUF=':';while(TI==0);TI=0;
			sendString(strdefault);
			break;
	}
	EA=1;
}
	