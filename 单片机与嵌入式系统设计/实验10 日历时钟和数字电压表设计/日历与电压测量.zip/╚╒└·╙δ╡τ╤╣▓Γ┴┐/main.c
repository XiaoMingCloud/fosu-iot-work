#include <REGX52.H>
#define uchar unsigned char	
#define uint unsigned int

sbit RS=P3^0;
sbit RW=P3^1;
sbit E=P3^2;

sbit T_RST=P3^3;
sbit T_CLK=P3^4;
sbit T_IO=P3^5;

sbit START=P0^0;
sbit EOC=P0^1;
sbit OE=P0^2;
uint AdcVol;
uchar t[]={"0123456789"};

sbit DATE=P3^6;
sbit VOL=P3^7;
uchar datechar[]={"DATE:"};
uchar timechar[]={"TIME:"};
uchar datebuffer[10]={0x32,0x30,0,0,0x2d,0,0,0x2d,0,0};
uchar timebuffer[8]={0,0,0x3a,0,0,0x3a,0,0};
uchar weekbuffer=0x30;

uchar str[]={"AT89C52-LCD1602"};
uchar str1[]={" Desianed Rv CYF"};
uchar str2[]={"VOLTAGE:"};

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
for(j=0;j<250;j++);
}

void writecom(unsigned char com)
{	
	RS=0; 
	RW=0; 
	E=0; 
	P2=com;
	delay(5);
	E=1;
	E=0;
}

void writedat(unsigned char dat)
{
	RS=1;
	RW=0;
	E=0;
	P2=dat;
	delay(5);
	E=1;
	E=0;
}

void initlcd()
{
	writecom(0x38);
	writecom(0x0C);
	writecom(0x06);
	writecom(0x01);
}

void WriteB(uchar dat)
{
	uchar i;
	for(i=8;i>0;i--)
	{
		T_IO=dat&0x01;
		T_CLK=1;
		T_CLK=0;
		dat=dat>>1;
	}
}

uchar ReadB(void)
{
	uchar i,readdat=0;
	for(i=8;i>0;i--)
	{
		readdat=readdat>>1;
		if(T_IO)
		{
			readdat|=0x80;
		}
		T_CLK=1;
		T_CLK=0;
	}
	return(readdat);
}

void W1302(uchar address,uchar dat)
{
	T_RST=0;
	T_CLK=0;
	delay(1);
	T_RST=1;
	WriteB(address);
	WriteB(dat);
	T_CLK=1;
	T_RST=0;
}
uchar R1302(uchar address)
{
	uchar dat=0;
	T_RST=0;
	T_CLK=0;
	T_RST=1;
	WriteB(address);
	dat=ReadB();
	T_CLK=1;
	T_RST=0;
	return(dat);
}

void display(void)
{
	uchar i=0;
	writecom(0x80);
	delay(3);
	while(str[i]!='\0')
	{
		writedat(str[i]);
		delay(3);
		i++;
	}
	writecom(0x80+0x40);
	delay(3);
	i=0;
	while(str1[i]!='\0')
	{
		writedat(str1[i]);
		delay(3);
		i++;
	}
}

void displaydate(void)
{
int i=0,temp=0;
temp=R1302(0x8d); 
datebuffer[2]=0x30+temp/16; 
datebuffer[3]=0x30+temp%16;

temp=R1302(0x8b); 
weekbuffer=0x30+temp;

temp=R1302(0x89); 
datebuffer[5]=0x30+temp/16; 
datebuffer[6]=0x30+temp%16;

temp=R1302(0x87);  
datebuffer[8]=0x30+temp/16; 
datebuffer[9]=0x30+temp%16;

temp=R1302(0x85); 
timebuffer[0]=0x30+temp/16; 
timebuffer[1]=0x30+temp%16;

temp=R1302(0x83); 
timebuffer[3]=0x30+temp/16; 
timebuffer[4]=0x30+temp%16;

temp=R1302(0x81);
timebuffer[6]=0x30+temp/16; 
timebuffer[7]=0x30+temp%16;

writecom(0x80); 
for(i=0;i<5;i++)
{
writedat(datechar[i]);
}
writecom(0xc0); 
for(i=0;i<5;i++)
{
writedat(timechar[i]);
}
writecom(0x86); 
for(i=0;i<10;i++)
{
writedat(datebuffer[i]);
}
writecom(0xc6); 
for(i=0;i<8;i++)
{
writedat(timebuffer[i]);
}
	writedat(' ');	
	writedat(weekbuffer); 

}

void setdate()
{
	W1302(0x08e,0);
	W1302(0x08c,0x24);
	W1302(0x08a,0x03);
	W1302(0x088,0x06);
	W1302(0x086,0x12);
	W1302(0x084,0x08);
	W1302(0x082,0x30);
	W1302(0x080,0x30);
	W1302(0x08e,0x80);
}

void adc()
{
	START=0;
	START=1;
	delay(5);
	START=0;
	while(EOC);
	while(!EOC);
	OE=1;
	AdcVol=P1;
	OE=0;
}

void displayvol()
{
	uchar i,temp0,temp1,temp2;
	AdcVol=AdcVol*100/51;
	temp0=AdcVol/100;
	temp1=AdcVol%100/10;
	temp2=AdcVol%10;
	
	writecom(0x80);
	i=0;
	while(str2[i]!='\0')
	{
		writedat(str2[i]);
		delay(3);
		i++;
	}
	writecom(0xC0+9);
	writedat('+');
	writedat(t[temp0]);
	writedat('.');
	writedat(t[temp1]);
	writedat(t[temp2]);
	writedat('V');
	
}

void main()
{
	initlcd();
	
	setdate();
	while(1)
	{
		display();
		if(DATE==0)
		{
			writecom(0x01);
			while(DATE==0)
			displaydate();
			delay(5);
			writecom(0x01);
		}
	
	
	
	if(VOL==0)
	{
		
		writecom(0x01);
		while(VOL==0)
		{
			adc();
			displayvol();
		}
		writecom(0x01);
	}
}
}