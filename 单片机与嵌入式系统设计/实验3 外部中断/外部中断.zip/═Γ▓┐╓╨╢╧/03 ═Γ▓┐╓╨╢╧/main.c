#include <REGX52.H>
#include<intrins.h>
void delay(unsigned int ms200);
void delay_5us();
void main()
{
unsigned char i;
TCON=0x01;
IE=0x85;
	
while(1){
for(i=0;i<8;i++)
		{
			P1=_crol_(0xfe,i);
			delay(300);
		}
	}
}

void exint0() interrupt 0
{
	unsigned char i;
	EA=0;
	for(i=0;i<3;i++)
	{
		P0=0xf0;
		delay(300);
		P0=0xff;
		delay(300);
	}
	EA=1;
}

void exint1() interrupt 2
{
	unsigned char i;
	EA=0;
	for(i=0;i<6;i++)
	{
		P2=0xf0;
		delay(300);
		P2=0xff;
		delay(300);
	}
	EA=1;
}
	

void delay_5us()
{
	_nop_();
	_nop_();
}

void delay(unsigned int ms200)
{
	unsigned char j;
	while(ms200>0)
		{
			for(j=0;j<110;j++) delay_5us();
			ms200--;
		}
	}