#include <REGX52.H>
#include <stdio.h>
#include <intrins.h>
void Delay1000ms(int x)		//@12.000MHz
{
	unsigned char i, j, k;

	_nop_();
	i = 8;
	j = 154;
	k = 122;
	while(x--){do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
	}
}

int main()
{
	int i=0;
	P2=0xff;
	while(1)
	{
		i=0;
		while (i != 8)
    {
        Delay1000ms(1);
        P2 = 0xff << i;
				//P2 = 0xFD;
        i++;
    }
		for(i=1;i<=8;i++){
					Delay1000ms(1);
					P2 = 0xff >> i;
					}
		for(i=1;i<=2;i++)
	{
		Delay1000ms(1);
		P2=0xff;
		Delay1000ms(1);
		P2=0x00;
	}
		for(i=1;i<=2;i++)
	{
		Delay1000ms(1);
		P2=0x55;
		Delay1000ms(1);
		P2=0xaa;
	}
		//Delay1000ms(1);
		
	}
}
