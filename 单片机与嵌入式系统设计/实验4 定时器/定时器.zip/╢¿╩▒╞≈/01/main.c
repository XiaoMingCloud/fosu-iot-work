#include<reg52.h>

sbit startButton=P0^0;
sbit pauseButton=P0^1;
sbit resetButton=P0^2;
sbit exitButton=P0^3;

bit int0_Mark;
unsigned char HEXtoBCD(unsigned char hex)
{
	return((hex/10)*16+(hex%10));
}
void main()
{
	unsigned char uc10ms=0,uc1s=0,uc60s=0;
	TMOD=0x01;
	IE=0x82;
	while(1)
	{
		uc10ms=0;uc1s=0;uc60s=0;
		P1=HEXtoBCD(uc10ms);
		P2=HEXtoBCD(uc1s);
		P3=HEXtoBCD(uc60s);
		while(startButton);
		while(!startButton);
		while(exitButton)
		{
			int0_Mark=1;
			TH0=0xDC;TL0=0x00;
			TR0=1;
			EA=1;
			while(int0_Mark);
			EA=0;
			TR0=0;
			
			uc10ms++;
			
			if(uc10ms==100){
				uc10ms=0;uc1s++;
			}
			P1=HEXtoBCD(uc10ms);
			
			if(uc1s==60){
				uc1s=0;uc60s++;
			}
			P2=HEXtoBCD(uc1s);			
						
			if(uc60s==60){
				uc60s=0;
			}
			P3=HEXtoBCD(uc60s);
			
			if(!pauseButton)
			{
				while(pauseButton);
				while(!pauseButton)
				{
						if(!pauseButton)
						{
							P1=HEXtoBCD(uc10ms);
							P2=HEXtoBCD(uc1s);
							P3=HEXtoBCD(uc60s);
						}
						if(exitButton==0)
							{
								exitButton=0;
								break;
							}
							while(!pauseButton);
				}
			}
						if(!resetButton)
						{
							uc10ms=0;
							uc1s=0;
							uc60s=0;
							P1=HEXtoBCD(uc10ms);
							P2=HEXtoBCD(uc1s);
							P3=HEXtoBCD(uc60s);
						}			
		}
	}
}

void timer0() interrupt 1
{
	EA=0;
	int0_Mark=0;
	TR0=0;
	TH0=0xDC;TL0=0x00;
	TR0=1;
	EA=1;
}