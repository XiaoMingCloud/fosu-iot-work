#include <REGX52.H>

sbit startButton=P0^0;
sbit pauseButton=P0^1;
sbit resetButton=P0^2;
sbit exitButton=P0^3;
sbit modeButton = P0^4;

bit int0_Mark;
unsigned char HEXtoBCD(unsigned char hex)
{
	return((hex/10)*16+(hex%10));
}
void main()
{
	unsigned char flag=1,uc1ms=0,uc10ms=0,uc1s=0;
	TMOD=0x01;
	IE=0x82;
	while(1)
	{
		TH0=0xFC;TL0=0x18;
		uc1ms=0;uc10ms=0;uc1s=0;
		if(modeButton==0)
		{
			uc1s=99;
		}
		P1=HEXtoBCD(uc1ms);
		P2=HEXtoBCD(uc10ms);
		P3=HEXtoBCD(uc1s);
		while(startButton);
		while(!startButton);
		if(modeButton==1)
		{
			while(exitButton)
		{
			int0_Mark=1;
			TH0=0xFC;TL0=0x18;
			TR0=1;
			EA=1;
			while(int0_Mark);
			EA=0;
			TR0=0;
			uc1ms++;
			
			if(uc1ms==10){
				uc10ms++;uc1ms=0;
			}
			P1=HEXtoBCD(uc1ms);			
			if(uc10ms==100)
			{
				uc10ms=0;uc1s++;
			}
			P2=HEXtoBCD(uc10ms);
			if(uc1s==100)
				uc1s=0;
			P3=HEXtoBCD(uc1s);	
			if(!pauseButton)
			{
				while(pauseButton);
				while(!pauseButton)
				{
						if(!pauseButton)
						{
							P1=HEXtoBCD(uc1ms);
							P2=HEXtoBCD(uc10ms);
							P3=HEXtoBCD(uc1s);
						}
						if(exitButton==0)
							{
								exitButton=0;
								break;
							}
							while(!pauseButton);
				}
			}
						if(!resetButton)
						{
							uc1ms=0;
							uc10ms=0;
							uc1s=0;
							P1=HEXtoBCD(uc1ms);
							P2=HEXtoBCD(uc10ms);
							P3=HEXtoBCD(uc1s);
						}			
		}
		}
		if(modeButton==0)
		{
			while(exitButton)
		{
			int0_Mark=1;
			TH0=0xFC;TL0=0x18;
			TR0=1;
			EA=1;
			while(int0_Mark);
			
			uc1ms--;
			if(uc1ms==0){
				uc10ms--;uc1ms=10;
			}
			P1=HEXtoBCD(uc1ms);			
			if(uc10ms==0)
			{
				uc10ms=100;uc1s--;
			}
			P2=HEXtoBCD(uc10ms);
			if(uc1s==0)
				uc1s=99;
			P3=HEXtoBCD(uc1s);	
			if(!pauseButton)
			{
				while(pauseButton);
				while(!pauseButton)
				{
						if(!pauseButton)
						{
							P1=HEXtoBCD(uc1ms);
							P2=HEXtoBCD(uc10ms);
							P3=HEXtoBCD(uc1s);
						}
						if(exitButton==0)
							{
								exitButton=0;
								break;
							}
							while(!pauseButton);
				}
			}
						if(!resetButton)
						{
							uc1ms=0;
							uc10ms=0;
							uc1s=99;
							P1=HEXtoBCD(uc1ms);
							P2=HEXtoBCD(uc10ms);
							P3=HEXtoBCD(uc1s);
						}			
		}
		}
	}
}

void timer0() interrupt 1
{
	EA=0;
	int0_Mark=0;
	TR0=0;
	TH0=0xFC;TL0=0x18;
	TR0=1;
	EA=1;
}