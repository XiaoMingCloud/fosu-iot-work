#include <REGX52.H>
#include <stdio.h>
#include <intrins.h>
void Delay1000ms(int x)		//@12.000MHz
{
	unsigned char i, j, k;
	_nop_();
	i = 8;
	j = 154;
	k = 122;
	while(x--){do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
	}
}

int main()
{
	while(1)
	{
			if(P1_0!=1)
			{
				Delay1000ms(1);
				P1_4=1;
				P1_5=1;
				P1_3=~P1_3;
				P1_2=~P1_2;
			}
		
		if(P1_1!=1)
			{
				Delay1000ms(1);
				P1_2=1;
				P1_3=1;
				P1_5=~P1_5;
				P1_4=~P1_4;
			}
		if(P1_0==P1_1==1)
		{
			P1_2=1;
			P1_3=1;
			P1_5=1;
			P1_4=1;
		}
		if(P1_6==0){
			P0_0=0;
			P0_1=0;
		}
		else{
			P0_0=1;
			P0_1=1;
		}
		if(P1_7!=1)
			{
				Delay1000ms(1);
				P0_2=~P0_2;
				P0_3=~P0_3;
				P0_4=~P0_4;
				P0_5=~P0_5;
			}
			else{
				P0_2=1;
				P0_3=1;
				P0_4=1;
				P0_5=1;
			}
	}
	
}
