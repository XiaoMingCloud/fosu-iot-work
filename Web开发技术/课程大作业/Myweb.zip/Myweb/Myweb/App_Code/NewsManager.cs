﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Text;

/// <summary>
///News_Manager 的摘要说明
/// </summary>
public class NewsManager
{
	public NewsManager()
	{
	}
    private const string SQL_INSERT_NEWSINFO ="INSERT INTO Newsinfo VALUES(@title,@data,@date,@imageurl,@category)";
    private const string PARM_NEWS_TITLE ="@title";
    private const string PARM_NEWS_DATA ="@data";
    private const string PARM_NEWS_DATE ="@date";
    private const string PARM_NEWS_CATEGORY ="@category";
    private const string PARM_NEWS_IMAGEURL ="@imageurl";
    public bool AddNews(string newsTitle, string newsData, string newsCategory, string imageUrl)
    {
        StringBuilder strSQL = new StringBuilder();
        SqlParameter[] newsParms = GetParameters();
        SqlCommand cmd = new SqlCommand();
        newsParms[0].Value = newsTitle;
        newsParms[1].Value = newsData;
        newsParms[2].Value = DateTime.Now;
        newsParms[3].Value = imageUrl;
        newsParms[4].Value = newsCategory;
        foreach (SqlParameter parm in newsParms)
            cmd.Parameters.Add(parm);
        using (SqlConnection conn = new SqlConnection(SqlHelper.ConnectionStringLocalTransaction))
        {
            strSQL.Append(SQL_INSERT_NEWSINFO);
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = strSQL.ToString();
            int val = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            if (val > 0)
                return true;
            else
                return false;
        }
    }
    private static SqlParameter[] GetParameters()
    {
        SqlParameter[] parms = SqlHelper.GetCachedParametes(SQL_INSERT_NEWSINFO);
        if (parms == null)
        {
            parms = new SqlParameter[]{
                new SqlParameter(PARM_NEWS_TITLE,SqlDbType.NVarChar,20),
                new SqlParameter(PARM_NEWS_DATA,SqlDbType.NVarChar,500),
                new SqlParameter(PARM_NEWS_DATE,SqlDbType.DateTime),
                new SqlParameter(PARM_NEWS_IMAGEURL,SqlDbType.NVarChar,50),
                new SqlParameter(PARM_NEWS_CATEGORY,SqlDbType.NVarChar,20)};
            SqlHelper.GetCachedParametes(SQL_INSERT_NEWSINFO);

        }
        return parms;
    }
}