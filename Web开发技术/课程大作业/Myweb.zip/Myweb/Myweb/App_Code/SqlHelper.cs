﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;

/// <summary>
///SqlHelper 的摘要说明
/// </summary>
public class SqlHelper
{
    public static readonly string ConnectionStringLocalTransaction = ConfigurationManager.ConnectionStrings["NewsConnectionString"].ConnectionString;
	public SqlHelper()
	{
	}
    private static Hashtable parmCache = Hashtable.Synchronized(new Hashtable());
    public static SqlParameter[] GetCachedParametes(string cacheKey) 
    {
        SqlParameter[] cachedParms = (SqlParameter[])parmCache[cacheKey];
        if (cachedParms == null)
            return null;
        SqlParameter[] clonedParms = new SqlParameter[cachedParms.Length];
        for (int i = 0, j = cachedParms.Length; i < j; i++)
            clonedParms[i] = (SqlParameter)((ICloneable)cachedParms[i]).Clone();
        return clonedParms;
    }
}