﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDisplay.Text = " ";
        }
    }
    protected void btnNumber_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        txtDisplay.Text += btn.CommandArgument;
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtDisplay.Text = " ";
    }
    protected void btnC_Click(object sender, EventArgs e)
    {
        txtDisplay.Text = "";
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string current = txtDisplay.Text;
        ViewState["Operand1"] = current;
        ViewState["Operation"] = "+";
        txtDisplay.Text = "";
    }
    protected void btnSubtract_Click(object sender, EventArgs e)
    {
        string current = txtDisplay.Text;
        ViewState["Operand1"] = current;
        ViewState["Operation"] = "-";
        txtDisplay.Text = "";
    }
    protected void btnMultiply_Click(object sender, EventArgs e)
    {
        string current = txtDisplay.Text;
        ViewState["Operand1"] = current;
        ViewState["Operation"] = "*";
        txtDisplay.Text = "";
    }
    protected void btnDivide_Click(object sender, EventArgs e)
    {
        string current = txtDisplay.Text;
        ViewState["Operand1"] = current;
        ViewState["Operation"] = "/";
        txtDisplay.Text = "";
    }
    protected void btnEquals_Click(object sender, EventArgs e)
    {
        string operand2 = txtDisplay.Text;
        double result = 0;
        switch ((string)ViewState["Operation"])
        {
            case "+":
                result = Convert.ToDouble(ViewState["Operand1"]) + Convert.ToDouble(operand2);
                break;
            case "-":
                result = Convert.ToDouble(ViewState["Operand1"]) - Convert.ToDouble(operand2);
                break;
            case "*":
                result = Convert.ToDouble(ViewState["Operand1"]) * Convert.ToDouble(operand2);
                break;
            case "/":
                if (operand2 != "0")
                {
                    result = Convert.ToDouble(ViewState["Operand1"]) / Convert.ToDouble(operand2);
                }
                else
                {
                    txtDisplay.Text = "Error";
                    return;
                }
                break;
        }
        txtDisplay.Text = result.ToString();
        ViewState["Operand1"] = result.ToString();
        ViewState["Operation"] = null;
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text.Length > 1)
        {
            txtDisplay.Text = txtDisplay.Text.Substring(0, txtDisplay.Text.Length - 1);
        }
        else if (txtDisplay.Text.Length == 1)
        {
            txtDisplay.Text = "";
        }
    }
}