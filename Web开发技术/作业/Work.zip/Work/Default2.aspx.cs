﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // 页面加载时初始化总金额
            howmuch.Text = "0";
        }
    }

    protected void add_Click(object sender, EventArgs e)
    {
        // 将选中的菜品添加到右侧的ListBox中，并更新总金额
        foreach (ListItem item in menu.Items)
        {
            if (item.Selected)
            {
                // 检查是否已经添加过相同的菜品
                if (!clickmenu.Items.Contains(item))
                {
                    clickmenu.Items.Add(new ListItem(item.Text, item.Value));
                }
                int price = int.Parse(item.Value);
                UpdateTotalAmount(price);
            }
        }
    }

    protected void minus_Click(object sender, EventArgs e)
    {
        // 将选中的菜品从右侧的ListBox中移除，并更新总金额
        for (int i = clickmenu.Items.Count - 1; i >= 0; i--)
        {
            if (clickmenu.Items[i].Selected)
            {
                int price = int.Parse(clickmenu.Items[i].Value);
                UpdateTotalAmount(-price); // 移除时金额为负值
                clickmenu.Items.RemoveAt(i);
            }
        }
    }

    private void UpdateTotalAmount(int amount)
    {
        int currentTotal = int.Parse(howmuch.Text);
        howmuch.Text = (currentTotal + amount).ToString();
    }
    
}