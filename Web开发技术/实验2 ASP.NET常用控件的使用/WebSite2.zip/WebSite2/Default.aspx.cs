﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button2.Value = "我变了";
    }
    protected void Button5_Click(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    private void ShowNumbers(object commandArgument)
    {
        Page.Response.Write("触发了方法ShowNumbers(" + commandArgument.ToString() + ")<br>");
        if (commandArgument.ToString() == "Ase")
            Page.Response.Write("1 2 3 4 5");
        else if (commandArgument.ToString() == "Desc")
            Page.Response.Write("5 4 3 2 1");

    }
    private void ShowLetters(object commandArgument)
    {
        Page.Response.Write("触发了方法ShowLetters(" + commandArgument.ToString() + ")<br>");
        if (commandArgument.ToString() == "Ase")
            Page.Response.Write("a b c d e");
        else if (commandArgument.ToString() == "Desc")
            Page.Response.Write("e d c b a");

    }
    protected void Button_Command(object sender, System.Web.UI.WebControls.CommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "ShowNumbers_Asc":
                Page.Response.Write("您单击了按钮“递增显示数字”！<br>");
                ShowNumbers(e.CommandArgument);
                break;
            case "ShowNumbers_Desc":
                Page.Response.Write("您单击了按钮“递减显示数字”！<br>");
                ShowNumbers(e.CommandArgument);
                break;
            case "ShowLetters_Asc":
                Page.Response.Write("您单击了按钮“递增显示数字”！<br>");
                ShowLetters(e.CommandArgument);
                break;
            case "ShowLetters_Desc":
                Page.Response.Write("您单击了按钮“递减显示数字”！<br>");
                ShowLetters(e.CommandArgument);
                break;
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if(RadioButton1.Checked==true)
            Response.Write("您的性别是：男");
        else
            Response.Write("您的性别是：女");
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton2.Checked == true)
            Response.Write("您的性别是：女");
        else
            Response.Write("您的性别是：男");
    }
    private void Show()
    {
        string result= "您选择的爱好有：";
        if (CheckBox1.Checked == true) result += "游泳 ";
        if (CheckBox2.Checked == true) result += "篮球 ";
        if (CheckBox3.Checked == true) result += "旅游 ";
        if (CheckBox4.Checked == true) result += "足球 ";
        if (CheckBox5.Checked == true) result += "阅读 ";
        if (CheckBox6.Checked == true) result += "电影 ";
        Response.Write(result);
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        Show();
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        Show();
    }
    protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
    {
        Show();
    }
    protected void CheckBox4_CheckedChanged(object sender, EventArgs e)
    {
        Show();
    }
    protected void CheckBox5_CheckedChanged(object sender, EventArgs e)
    {
        Show();
    }
    protected void CheckBox6_CheckedChanged(object sender, EventArgs e)
    {
        Show();
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Write("您的爱好是：");
        for (int i = 0; i < ListBox1.Items.Count; i++)
        {
            if (ListBox1.Items[i].Selected)
                Response.Write(ListBox1.Items[i].Text+" "); 
        }
    }
  
}