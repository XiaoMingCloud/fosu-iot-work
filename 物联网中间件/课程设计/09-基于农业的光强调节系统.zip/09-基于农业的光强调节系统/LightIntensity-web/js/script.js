/***********************************************************************************
 * 文件：LightIntensity（农业关照调节系统）
 *
 * 作者：Chenyang 		2016.10.17
 *
 * 说明：主js包括导航与按钮功能的实现和数据的连接，实现整个系统的功能
 *
 * 修改：Zhouly 			    2016.11.23     	1.优化代码格式，细化注释
 *                        							        	2.将script.js文件与connect.js文件合并成script.js文件
 *
 *           Chenyang          2016.12.9        添加localStorage本地存储、分享生成二维码及安卓扫码功能
 * *********************************************************************************/
// 定义本地存储参数
var localData = {
    ID :config['9262873964'],
    KEY :config['GRpU3RCs4KZIQPGNR5iUbRznAXhs36z7'],
    server : config['10.130.8.247:28080'],
	lightMAC : "00:12:4B:00:1A:C4:20:CB",
	tempHumMAC : "00:12:4B:00:1A:C4:20:C8",
	stepMotorMAC : "01:12:4B:00:D5:C5:09:99",
	rgbLedMAC : "01:12:4B:00:25:0D:B6:14",
	lightRangeTop : "3000",
	lightRangeBottom : "1000"
};
var cur_scan_id;

$(function (){
	// 初始化顶级导航和二级导航
	Nav.topNav($('.top-nav li'));
	$('.content:eq(0)').css('display', 'block');
	Nav.secondNav($('.side-nav:eq(0) li'),0);
	$('.content:eq(0) .main:eq(0)').css('display','block');

	// 顶级导航按钮
	Button.topNavBtn();

	// 获取本地存储的id key server等
	get_localStorage();

	// id key 及标志位变量定义
	var connectFlag = 0, macFlag = 0;
	var rtc = 0;
	// 传感器参数定义
	var lightData, stepMotorData, rgbLedData,temperData,humidityData,myHisData;
	// 操作标志位
	var stepMotorMode = 1;
	var rgbLedMode = 1;
    getConnect();
	// id key输入确认按钮
	$("#idkeyInput").click(function() {
        localData['ID'] = $("#ID").val();
        localData['KEY'] = $("#KEY").val();
        localData['server'] = $("#server").val();
        console.log(localData['ID']);
        console.log(localData['KEY']);
        console.log(localData['server']);
        // 本地存储id、key和server
        storeStorage();
        if(!connectFlag && rtc!=0){
            getConnect();
        }else{
            rtc.disconnect();
        }
    });


    // 建立数据连接
    function getConnect() {
        localData['ID'] = localData['ID'] ? localData['ID'] : config['id'];
        localData['KEY'] = localData['KEY'] ? localData['KEY'] : config['key'];
        localData['server'] = localData['server'] ? localData['server'] : config['server'];
        $("#ID").val(localData['ID']);
        $("#KEY").val(localData['KEY']);
        $("#server").val( localData['server'] );
        // 创建数据连接服务对象
        rtc = new WSNRTConnect(localData['ID'], localData['KEY']);
        rtc.setServerAddr(localData['server'] + ":28080");
        rtc.connect();

        // 连接成功回调函数
        rtc.onConnect = function () {
            // $("#ConnectState").text("数据服务连接成功！");
            // connectFlag = 1;
            // message_show("数据服务连接成功！");
            $("#ConnectState").text("数据服务连接成功！");
            connectFlag = 1;
            message_show("数据服务连接成功！");
            $("#idkeyInput").text("断开").addClass("btn-danger");
            $("#macInput").click();
        };
		//数据服务掉线回调函数
		rtc.onConnectLost = function () {
			connectFlag = 0;
			$("#idkeyInput").text("连接").removeClass("btn-danger");
			$("#ConnectState").text("数据服务连接掉线！");
			message_show("数据服务连接失败，检查网络或IDKEY");
			$(".float-right").text("离线").css("color", "#e75d59");
			$("#idkeyInput").text("连接").removeClass("btn-danger");
		};

        // 数据服务掉线回调函数
        rtc.onConnectLost = function () {
            connectFlag = 0;
            $("#idkeyInput").text("连接").removeClass("btn-danger");
            $("#ConnectState").text("数据服务连接掉线！");
            message_show("数据服务连接失败，检查网络或IDKEY");
            $("#lightLink").text("离线").css("color", "#e75d59");
            $("#stepMotorLink").text("离线").css("color", "#e75d59");
            $("#rgbLedLink").text("离线").css("color", "#e75d59");
        };


        // 消息处理回调函数
        rtc.onmessageArrive = function (mac, dat) {
            if (mac == localData.lightMAC) {
                if (dat[0] == '{' && dat[dat.length - 1] == '}') {
                    dat = dat.substr(1, dat.length - 2);
                    var its = dat.split(',');
                    for (var x in its) {
                        var t = its[x].split('=');
                        if (t.length != 2) continue;
                        if (t[0] == "A0") {
                            lightData = parseInt(t[1]);
                            lightDisplay(lightData);
                            if (stepMotorMode) {
                                if (lightData >= localData.lightRangeTop) {
                                    rtc.sendMessage(localData.stepMotorMAC, "{CD1=12,OD1=4,D1=?}");
                                } else {
                                    rtc.sendMessage(localData.stepMotorMAC, "{OD1=12,D1=?}");
                                }
                            }
                            if (rgbLedMode) {
                                if (lightData <= localData.lightRangeBottom) {
                                    rtc.sendMessage(localData.rgbLedMAC, "{OD1=1,D1=?}");
                                } else {
                                    rtc.sendMessage(localData.rgbLedMAC, "{CD1=1,D1=?}");
                                }
                            }
                            $("#lightLink").text("在线").css("color", "#b9ba65");
                            // 更新图表
                            console.log("lightData=" + lightData);
                        }
                    }
                }
            }
			else if (mac == localData.tempHumMAC) {
				if (dat[0] == '{' && dat[dat.length - 1] == '}') {
					dat = dat.substr(1, dat.length - 2);
					var its = dat.split(',');
					for (var x in its) {
						var t = its[x].split('=');
						console.log(t);
						if (t.length != 2) continue;
						if (t[0] == "A0") {
							temperData = parseInt(t[1]);
							temperDisplay(temperData);
							$("#temperStatus").text("在线").css("color", "#96ba5c");
							// 更新图表
							console.log("temperData=" + temperData);
						}
						else if (t[0] == "A1") {
							humidityData = parseInt(t[1]);
							humidityDisplay(humidityData);
							$("#humidityStatus").text("在线").css("color", "#96ba5c");
							// 更新图表
							console.log("humidityData=" + humidityData);
						}

					}
				}
			}
            else if (mac == localData.stepMotorMAC) {
                if (dat[0] == '{' && dat[dat.length - 1] == '}') {
                    dat = dat.substr(1, dat.length - 2);
                    var its = dat.split(',');
                    for (var x in its) {
                        var t = its[x].split('=');
                        if (t.length != 2) continue;
                        if (t[0] == "D1") {
                            stepMotorData = parseInt(t[1]);
                            if (stepMotorData & 0x04) {
                                if (stepMotorData & 0x08) {
                                    $("#stepMotorStatus").attr("src", "img/curtains-on.png");
                                    message_show("遮阳棚收起");
                                    console.log("5秒后关闭！");
                                    //延时5秒后关闭
                                    setTimeout(closeStepMotor, 5000);
                                } else {
                                    $("#stepMotorStatus").attr("src", "img/curtains-off.png");
                                    message_show("遮阳棚张开");
                                    console.log("5秒后关闭！");
                                    //延时5秒后关闭
                                    setTimeout(closeStepMotor, 5000);
                                }
                            } else {
                                message_show("遮阳电机关闭");
                            }
                            $("#stepMotorLink").text("在线").css("color", "#b9ba65");
                            // 更新图表
                            console.log("stepMotorData=" + stepMotorData);
                        }
                    }
                }
            }
            else if (mac == localData.rgbLedMAC) {
                if (dat[0] == '{' && dat[dat.length - 1] == '}') {
                    dat = dat.substr(1, dat.length - 2);
                    var its = dat.split(',');
                    for (var x in its) {
                        var t = its[x].split('=');
                        if (t.length != 2) continue;
                        if (t[0] == "D1") {
                            rgbLedData = parseInt(t[1]);
                            if (rgbLedData & 0x01) {
                                $("#rgbLedStatus").attr("src", "img/LED-on.png");
                                message_show("补光灯打开");
                            } else {
                                $("#rgbLedStatus").attr("src", "img/LED-off.png");
                                message_show("补光灯关闭");
                            }
                            $("#rgbLedLink").text("在线").css("color", "#b9ba65");
                            // 更新图表
                            console.log("rgbLedData=" + rgbLedData);
                        }
                    }
                }
            }
        }



        function closeStepMotor() {
            rtc.sendMessage(localData.stepMotorMAC, '{CD1=12,D1=?}');
        }

    }
	// mac地址输入确认按钮
	$("#macInput").click(function(){
		localData.lightMAC = $("#lightMAC").val();
		localData.tempHumMAC = $("#tempHumMAC").val();
		localData.stepMotorMAC = $("#stepMotorMAC").val();
		localData.rgbLedMAC = $("#rgbLedMAC").val();
		// 本地存储mac地址
        storeStorage();
		console.log("flag" + connectFlag);
		if (connectFlag) {
			rtc.sendMessage(localData.lightMAC, "{A0=?}"); 
			console.log(localData.lightMAC);

			rtc.sendMessage(localData.tempHumMAC, "{A0=?,A1=?}");
			console.log(localData.tempHumMAC);

			rtc.sendMessage(localData.stepMotorMAC, "{D1=?}");
			console.log(localData.stepMotorMAC);

			rtc.sendMessage(localData.rgbLedMAC, "{D1=?}"); 
			console.log(localData.rgbLedMAC);
			macFlag = 1;
			message_show("MAC设置成功");
		}else {
			macFlag = 0;
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 步进电机自动模式
	$("#stepMotorAutoMode").click(function(){
		if(connectFlag){
			if(macFlag){
				stepMotorMode = 1;
				message_show("步进电机智能模式设置成功！");
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 步进电机手动模式
	$("#stepMotorHandMode").click(function(){
		if(connectFlag){
			if(macFlag){
				stepMotorMode = 0;
				message_show("步进电机人工模式设置成功！");
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 电机阀值确定按钮
	$("#lightTopInput").click(function(){
		localData.lightRangeTop = $("#lightRangeTop").val();
		// 本地存储电机阀值
        storeStorage();
		if(connectFlag) {
			if(macFlag){
				if (stepMotorMode) {
					message_show("遮阳电机控制阀值设置成功！");
					rtc.sendMessage(localData.lightMAC, "{A0=?}");
				}else {
					message_show("请在智能模式下操作！");
				}
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 步进电机-开
	$("#stepMotorOn").click(function(){
		if(connectFlag) {
			if(macFlag){
				if (stepMotorMode == 0) {
					rtc.sendMessage(localData.stepMotorMAC, "{CD1=12,OD1=4,D1=?}");
				}else {
					message_show("请在步进电机人工模式下操作！");
				}
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 步进电机-关
	$("#stepMotorOff").click(function(){
		if(connectFlag) {
			if(macFlag){
				if (stepMotorMode == 0) {
					rtc.sendMessage(localData.stepMotorMAC, "{OD1=12,D1=?}");
				}else {
					message_show("请在步进电机人工模式下操作！");
				}
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 补光灯智能模式
	$("#rgbLedAutoMode").click(function(){
		if(connectFlag){
			if(macFlag){
				rgbLedMode = 1;
				message_show("补光灯智能模式设置成功！");
				rtc.sendMessage(localData.lightMAC, "{D1=?}");
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 补光灯手动模式
	$("#rgbLedHandMode").click(function(){
		if(connectFlag){
			if(macFlag){
				rgbLedMode = 0;
				message_show("补光灯人工模式设置成功！");
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 补光灯阀值确认按钮
	$("#lightBottomInput").click(function(){
		localData.lightRangeBottom = $("#lightRangeBottom").val();
		// 本地存储补光灯阀值
        storeStorage();
		if(connectFlag) {
			if(macFlag){
				if (rgbLedMode) {
					message_show("补光灯控制阀值设置成功！");
					rtc.sendMessage(localData.lightMAC, "{D1=?}");
				}else {
					message_show("请在补光灯智能模式下操作！");
				}
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 补光灯-开
	$("#rgbLedOn").click(function(){
		if(connectFlag) {
			if(macFlag){
				if (rgbLedMode == 0) {
					rtc.sendMessage(localData.rgbLedMAC, "{OD1=1,D1=?}"); 
				}else {
					message_show("请在补光灯人工模式下操作！");
				}
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 补光灯-关
	$("#rgbLedOff").click(function(){
		if(connectFlag) {
			if(macFlag){
				if (rgbLedMode == 0) {
					rtc.sendMessage(localData.rgbLedMAC, "{CD1=1,D1=?}"); 
				}else {
					message_show("请在补光灯人工模式下操作！");
				}
			}else {
				message_show("请设置传感器MAC");
			}
		}else {
			message_show("请正确输入IDKEY连接智云数据中心");
		}
	});

	// 光照度历史数据
	$("#lightHistoryDisplay").click(function(){
		// 初始化api， 实例化历史数据
		var myHisData = new WSNHistory(localData.ID, localData.KEY);
		// 服务器接口查询
		myHisData.setServerAddr(localData.server+":8080");
		// 设置时间
		var time = $("#lightSet").val();
		console.log(time);
		// 设置数据通道
		var channel = localData.lightMAC+"_A0";
		console.log(channel);
		myHisData[time](channel, function(dat){
			if(dat.datapoints.length >0) {
				var data = DataAnalysis(dat);
				showChart('#his_light', 'spline', '', false, eval(data));
			} else {
				message_show("该时间段没有数据");
			}
		});
	});

	//温度历史数据查询
	$("#TemHistoryDisplay").click(function(){
		//初始化api
		var myHisData = new WSNHistory(localData.ID, localData.KEY);
		myHisData.setServerAddr(localData.server+":8080");
		var time = $("#TemSet").val();
		console.log(time);
		//设置数据通道
		var channel = localData.tempHumMAC+"_A0";
		console.log(channel);
		myHisData[time](channel, function(dat){
			if(dat.datapoints.length >0) {
				var data = DataAnalysis(dat);
				showChart('#her_Tem', 'spline', '', false, eval(data));
			} else {
				message_show("该时间段没有数据");
			}
		});
	});
//湿度历史数据查询
	$("#HumiHistoryDisplay").click(function(){
		//初始化api
		var myHisData = new WSNHistory(localData.ID, localData.KEY);
		myHisData.setServerAddr(localData.server+":8080");
		var time = $("#HumiSet").val();
		console.log(time);
		//设置数据通道
		var channel = localData.tempHumMAC+"_A1";
		console.log(channel);
		myHisData[time](channel, function(dat){
			if(dat.datapoints.length >0) {
				var data = DataAnalysis(dat);
				showChart('#her_Humi', 'spline', '', false, eval(data));
			} else {
				message_show("该时间段没有数据");
			}
		});
	});



	// 定义二维码生成div
	var qrcode = new QRCode(document.getElementById("qrDiv"), {
		width : 200,
		height : 200
	});

	// 分享按钮
	$(".share").on("click", function () {
		var txt="", title, input,obj;
        if(this.id=="idShare"){
            obj = {
                "id" : $("#ID").val(),
                "key" : $("#KEY").val(),
                "server" : $("#server").val(),
            }
            title = "IDKey";
            txt = JSON.stringify(obj);
        }else{
			$(this).parents(".MAC").find("input").each(function(){
				txt+= $(this).val()+",";
			});
			if(txt.length > 0){
				txt = txt.substr(0, txt.length - 1);
			}
			title = "MAC设置";
		}
		qrcode.makeCode(txt);
		$("#shareModalTitle").text(title)
	})

    // 扫描按钮
    $(".scan").on("click", function () {
        cur_scan_id=this.id;
        if (window.droid) {
            window.droid.requestScanQR("scanQR");
        }else{
            message_show("扫描只在安卓系统下可用！");
        }
    })

    // 升级按钮
    $("#setUp").click(function(){
        message_show("当前已是最新版本");
    });
//清楚缓存
    $("#clear").click(function(){
        localStorage.removeItem("lightIntensity");
        alert("localStorage已清除!")
        window.location.reload();
    })
    //  查看升级日志
    $("#showUpdateTxt").on("click", function () {
        if($(this).text()=="查看升级日志")
            $(this).text("收起升级日志");
        else
            $(this).text("查看升级日志");
    })

});
function getback(){
    $("#backModal").modal("show");
}

function confirm_back(){
    window.droid.confirmBack();
}
function storeStorage(){
	localStorage.setItem('lightIntensity',JSON.stringify(localData))
}
// 获取本地localStorage缓存数据
function get_localStorage(){
    if(localStorage['lightIntensity']){
    	localData=JSON.parse(localStorage.getItem('lightIntensity'))
        console.log("localData="+localData);
        for(var i in localData){
            if(localData[i]!=""){
                eval("$('#"+i+"').val(localData."+i+")");
                console.log("i="+i+";;  data1:"+localData[i]);
            }
        }
    }
}
// 扫描处理函数
function scanQR(scanData){
    //将原来的二维码编码格式转换为json。注：原来的编码格式如：ID:12345,KEY:12345,SERVER:12345
    var dataJson = {};
    if (scanData[0]!='{') {
        var data = scanData.split(',');
        for(var i=0;i<data.length;i++){
            var newdata = data[i].split(":");
            dataJson[newdata[0].toLocaleLowerCase()] = newdata[1];
        }
    }else{
        dataJson = JSON.parse(scanData);
    }
    console.log("dataJson="+JSON.stringify(dataJson));
    if(cur_scan_id == "id_scan"){
        $("#ID").val(dataJson['id']);
        $("#KEY").val(dataJson['key']);
        if(dataJson['server']&&dataJson['server']!=''){
            $("#server").val(dataJson['server']);
        }
    }
    else if(cur_scan_id=="mac_scan"){
    	var arr = scanData.split(",");
    	for(var i=0;i<arr.length;i++){
    		$(".MAC").find("input:eq("+i+")").val(arr[i]);
		}
        // $("#lightMAC").val(dataJson['lightMAC']);
        // $("#stepMotorMAC").val(dataJson['stepMotorMAC']);
        // $("#rgbLedMAC").val(dataJson['rgbLedMAC']);
    }
}




// 导航
var Nav = {
	// 顶级导航
	topNav : function (object) {
		object.click(function() {
			Active.navActive($(this));
			var num = $(this).index();
			$('.content').css('display','none');
			$('.content:eq(' + num + ')').css('display','block');
			$('.side-nav').css('display','none');
			$('.side-nav:eq(' + num + ')').css('display','block');
			// 初始化二级导航
			Nav.secondNav($('.side-nav:eq(' + num + ') li'),num);
			$('.side-nav:eq(' + num + ') li').removeClass('active');
			$('.side-nav:eq(' + num + ') li:eq(0)').addClass('active');
			$('.content:eq(' + num + ') .main').css('display','none');
			$('.content:eq(' + num + ') .main:eq(0)').css('display','block');
		});
	},
	// 二级导航
	secondNav : function (object,topNum) {
		object.click(function() {
			Active.navActive($(this));
			var num = $(this).index();
			$('.content:eq(' + topNum + ') .main').css('display','none');
			$('.content:eq(' + topNum + ') .main:eq(' + num + ')').css('display','block');
		});
	}
}
// 高亮
var Active = {
	// 导航栏高亮
	navActive : function (object) {
		object.siblings().removeClass('active')
		if (object.attr('class') != 'active') {
			object.addClass('active')
		}
	}
}
// 按钮
var Button = {
	// 顶级导航按钮
	topNavBtn: function () {
		$('.top-nav-btn').click(function(event) {
			$('.top-nav').fadeToggle();
		});
	},
	// 模式设置按钮
	modelBtn: function (object) {
		var name = object.attr('name');
		$('button[name="' + name + '"]').removeClass('btn-primary').addClass('btn-default');
		object.addClass('btn-primary');
	}
}

// 消息弹出框
var message_timer = null;
function message_show(t) {
	if (message_timer) {
		clearTimeout(message_timer);
	}
	message_timer = setTimeout(function () {
		$("#toast").hide();
	}, 3000);
	$("#toast_txt").text(t);
    console.log(t);
	$("#toast").show();
}



