package com.zonesion.util.js;

public class JsBleInterface {

}
