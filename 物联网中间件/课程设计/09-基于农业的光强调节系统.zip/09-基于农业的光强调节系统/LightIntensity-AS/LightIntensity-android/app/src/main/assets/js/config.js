/**
 * Created by zonesion on 2017/9/21.
 */
var config={
    'id':'1234567890',
    'key':'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    'server':'api.zhiyun360.com'
}









