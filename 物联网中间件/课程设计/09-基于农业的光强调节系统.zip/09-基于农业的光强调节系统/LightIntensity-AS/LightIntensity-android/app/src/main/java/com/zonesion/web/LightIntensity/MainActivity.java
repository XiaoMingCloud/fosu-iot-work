package com.zonesion.web.LightIntensity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.zonesion.util.js.JSRestInterface;
import com.zonesion.zxbee.ble.beacon.MTBeacon;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@SuppressLint("NewApi")
public class MainActivity extends Activity {

	WebView mWebView;
	private Handler mHandler = new Handler();
	
	int REQUEST_ENABLE_BT = 1001;
	
	static final String KEY_BIND_DEV_ADDR = "_bind_dev_addr";

	String mCurrentBindAddr ="";
	JSRestInterface mJSRestInterface;
	
	BluetoothManager mBluetoothManager;
	BluetoothAdapter mBluetoothAdapter;
	
	SharedPreferences mSharedPreferences;
	
    @SuppressLint("NewApi")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
   	 	
   	 	mSharedPreferences= getSharedPreferences("xble", 
   			Activity.MODE_PRIVATE);
   	 	
   		mWebView = (WebView) findViewById(R.id.webView);
   		mWebView.getSettings().setDefaultTextEncodingName("UTF-8") ;
   		mWebView.getSettings().setJavaScriptEnabled(true);
   		mWebView.getSettings().setUseWideViewPort(true); 
   		mWebView.getSettings().setLoadWithOverviewMode(true);
   		mWebView.getSettings().setDomStorageEnabled(true);     
   		mWebView.setWebViewClient(new WebViewClient(){       
               public boolean shouldOverrideUrlLoading(WebView view, String url) {       
                   view.loadUrl(url);       
                   return true;        
               }        
   		});
   		mWebView.setWebChromeClient(new WebChromeClient() { 
   			public void onConsoleMessage(String message, int lineNumber, String sourceID) { 
   				Log.d("JScript Log", sourceID+":"+lineNumber+": "+message ); 
   			}
	   		 @Override
	         public void onReceivedTitle(WebView view, String title) {
	   			MainActivity.this.setTitle(title);//a textview
	         }
   		});
   		
   		
   		mJSRestInterface = new JSRestInterface(this, mWebView, mHandler);
   		
   		mWebView.addJavascriptInterface(mJSRestInterface, "droid");
   		
        mWebView.loadUrl("file:///android_asset/index.html");
         
		//bindService(new Intent("com.zonesion.zxbee.ble.BLEService"), connection, BIND_AUTO_CREATE);
		
        mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
		if (null == mBluetoothManager) {
			return ;
		}
		mBluetoothAdapter = mBluetoothManager.getAdapter();
		if (null == mBluetoothAdapter) {
			return ;
		}
    }
    
    @SuppressLint("NewApi")
	public void onResume(){
    	super.onResume();
    	//startLeScan();
    }
    
    @SuppressLint("NewApi")
	public void onPause() {
    	
    	//stopLeScan();
    	super.onPause();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if(keyCode == KeyEvent.KEYCODE_BACK) {
        	callJS("getback", "");
        	return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    
	@SuppressLint("NewApi")
	private void callJS(String fun, String args) {

		final String s = "javascript:" + fun + "(" + args + ")";

		mHandler.post(new Runnable() {
			public void run() {

				mWebView.loadUrl(s);
			}
		});
	}
    
    public void onDestroy(){
    	//stopScanBle();
    	//unbindService(connection);
    	if(mBluetoothGatt != null){
			mBluetoothGatt.disconnect();
			mBluetoothGatt.close();
			mBluetoothGatt = null;
		}
    	
    	super.onDestroy();
    	System.exit(0);
    }
/*
    @SuppressLint("NewApi")
	private void startLeScan() {
    	scan_devices.clear();
    	scan_flag = true;
    	mBluetoothAdapter.startLeScan(mLeScanCallback);
    	search_timer.sendEmptyMessageDelayed(1, 1000);
	}
    private void stopLeScan(){
    	scan_flag = false;
    	mBluetoothAdapter.stopLeScan(mLeScanCallback);
    }*/
    

	
	private List<MTBeacon> scan_devices = new ArrayList<MTBeacon>();
	
	@SuppressLint("NewApi") 
	private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

		@Override
		public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
			int i = 0;
			//Log.d("BLE scan", "device :"+ device.getAddress() + " "+device.getName());

			for (i = 0; i < scan_devices.size(); i++) {
				if (0 == device.getAddress().compareTo(
						scan_devices.get(i).GetDevice().getAddress())) {
					scan_devices.get(i).ReflashInf(device, rssi, scanRecord); // ������Ϣ
					
					String s = "{mac:\""+device.getAddress()+"\",name:\""+device.getName()+"\", rssi:"+rssi+"}";
					mJSRestInterface.onLeScan(1, s);
					
					return; 
				}
			}
			scan_devices.add(new MTBeacon(device, rssi, scanRecord));
			String s = "{mac:\""+device.getAddress()+"\",name:\""+device.getName()+"\", rssi:"+rssi+"}";
			mJSRestInterface.onLeScan(0, s);
		}
	};
  
	
	private boolean scan_flag = false;
	boolean request_onBind = false;
	Handler search_timer = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 1) {
				for (int i = 0; i < scan_devices.size();) {
					if (scan_devices.get(i).getActiveCount() == 0) {
						MTBeacon device = scan_devices.get(i);
						
						String s = "{mac:\""+device.GetDevice().getAddress()+"\",name:\""+device.GetDevice().getName()+"\", rssi:"+0+"}";
						mJSRestInterface.onLeScan(2, s);
						scan_devices.remove(i);
					} else {
						scan_devices.get(i).reduceActiveCount();
						i++;
					}
					
				}
				if (scan_flag)search_timer.sendEmptyMessageDelayed(1, 1000);
			}
			if (msg.what == 2) {
				if(mBluetoothGatt != null){
					mBluetoothGatt.disconnect();
					mBluetoothGatt.close();
					mBluetoothGatt = null;
				}
				//mJSRestInterface.onBind(mCurrentBindAddr);
				if (mCurrentBindAddr.length() > 0) {	
					if (request_onBind) {
						request_onBind = false;
					}
					connectBle();
				}
			}
		}
	};
	private BluetoothGatt mBluetoothGatt;

	
	public void reqConnect(String mac) {
		if (!mCurrentBindAddr.equals(mac)) {
			//mSharedPreferences.edit().putString(KEY_BIND_DEV_ADDR, mac).commit();
			mCurrentBindAddr = mac;
			
			request_onBind = true;
			//mJSRestInterface.onBind(mCurrentBindAddr);

			search_timer.sendEmptyMessage(2);
		}
		//connectBle();
	}
	private void connectBle() {
		BluetoothDevice device_tmp = null;
		try {
			device_tmp = mBluetoothAdapter.getRemoteDevice(mCurrentBindAddr);
		} catch(Exception e) {
			
		}
		if(device_tmp == null){
			return;
		}
		
		mBluetoothGatt = device_tmp.connectGatt(getApplicationContext(), false,
				mGattCallback);
	}
	public void LeDisconnect(){
		if(mBluetoothGatt != null){
			mBluetoothGatt.disconnect();
			mBluetoothGatt.close();
			mBluetoothGatt = null;
		}
	}
	boolean connect_flag = false;
	private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

		@Override
		public void onConnectionStateChange(BluetoothGatt gatt, int status,
				int newState) {
			super.onConnectionStateChange(gatt, status, newState);
			if (newState == BluetoothProfile.STATE_CONNECTED) {
				System.out.println("CONNECTED");
				connect_flag = true;
				mBluetoothGatt.discoverServices();
				//broadcastUpdate(ACTION_STATE_CONNECTED);
				String mac = mBluetoothGatt.getDevice().getAddress();
				//mJSRestInterface.onLeConnect();


			} else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
				System.out.println("UNCONNECTED");
				connect_flag = false;
				//broadcastUpdate(ACTION_STATE_DISCONNECTED);
				mJSRestInterface.onLeUnconnect();
				search_timer.sendEmptyMessageDelayed(2, 3000);
			} 

		}  

		@Override
		public void onServicesDiscovered(BluetoothGatt gatt, int status) {
			super.onServicesDiscovered(gatt, status);
			if (status == BluetoothGatt.GATT_SUCCESS) {
				System.out.println("onServicesDiscovered");
				
					
					UUID su = UUID.fromString("0000aaa0-0000-1000-8000-00805f9b34fb");
					UUID cu = UUID.fromString("0000aaa1-0000-1000-8000-00805f9b34fb"); 
					BluetoothGattCharacteristic c = gatt.getService(su).getCharacteristic(cu);

					//BluetoothGattCharacteristic c = new BluetoothGattCharacteristic(x, BluetoothGattCharacteristic.PROPERTY_WRITE, BluetoothGattCharacteristic.PERMISSION_READ);
					gatt.setCharacteristicNotification(c, true);
					BluetoothGattDescriptor descriptor = c.getDescriptor(UUID
									.fromString("00002902-0000-1000-8000-00805f9b34fb"));
					descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
					gatt.writeDescriptor(descriptor);
				 
					mJSRestInterface.onLeConnect();
			}
		} 

		@Override
		public void onDescriptorRead(BluetoothGatt gatt,
				BluetoothGattDescriptor descriptor, int status) {
			super.onDescriptorRead(gatt, descriptor, status);

			//broadcastUpdate(ACTION_READ_Descriptor_OVER, status);
		}

		@Override
		public void onCharacteristicRead(BluetoothGatt gatt,
				BluetoothGattCharacteristic characteristic, int status) {
			super.onCharacteristicRead(gatt, characteristic, status);
			
			if (status == BluetoothGatt.GATT_SUCCESS) {
				//broadcastUpdate(ACTION_READ_OVER, characteristic.getValue());
			}
		} 

		@Override
		public void onCharacteristicChanged(BluetoothGatt gatt,
				BluetoothGattCharacteristic characteristic) {
			super.onCharacteristicChanged(gatt, characteristic);
			//broadcastUpdate(ACTION_DATA_CHANGE, characteristic.getValue());
			String dat = new String(characteristic.getValue());
			Log.d("ble", gatt.getDevice().getAddress()+" >>> "+dat);
			mJSRestInterface.onLeMessage(dat);
		}
		 
  
		@Override 
		public void onCharacteristicWrite(BluetoothGatt gatt,
				BluetoothGattCharacteristic characteristic, int status) {
			super.onCharacteristicWrite(gatt, characteristic, status);
			//broadcastUpdate(ACTION_WRITE_OVER, status);
			Log.d("liren_ble", "onCharacteristicWrite....");
			//mSendQue.remove(0);
			synchronized (mLock){
				mWaitSend = mWaitSend.substring(wSendLength);
			}
			mTimerSend.sendEmptyMessage(0);
		}

	};  
	      
	long mSendTm = 0;
	//List<String> mSendQue = new ArrayList();
	String mWaitSend = ""; 
	int wSendLength = 0;
	Handler mTimerSend = new Handler(){
		@Override
		public void handleMessage(Message m) { 
			if (m.what == 0) {
				if (mWaitSend.length() > 0) {
					String st;
					synchronized (mLock){
						if (mWaitSend.length()>20) {
							st = mWaitSend.substring(0, 20);
							//mWaitSend = mWaitSend.substring(20);
							
						} else {
							st = mWaitSend;
							//mWaitSend = "";
						}
					}
					wSendLength = st.length();
					//String a = mSendQue.get(0);
					//mSendQue.remove(0);
					UUID su = UUID.fromString("0000aaa0-0000-1000-8000-00805f9b34fb");
					UUID cu = UUID.fromString("0000aaa1-0000-1000-8000-00805f9b34fb");
					if (mBluetoothGatt != null) {
						
						BluetoothGattCharacteristic c = mBluetoothGatt.getService(su).getCharacteristic(cu);
						c.setValue(st);
						Log.d("liren_ble", "characteristicWrite.....");
						Log.d("ble", " >>> "+st);
						mBluetoothGatt.writeCharacteristic(c);
						//mTimerSend.sendEmptyMessageDelayed(1, 5000);
					}
				}
			} else if (m.what == 1) {
				//Log.d("liren_ble", "send timeout "+mSendQue.get(0));
				//if (mSendQue.size()>0){
					//	mSendQue.remove(0);
				//}
				//mTimerSend.sendEmptyMessage(0);
			}
		}
	};
	Object mLock = new Object();
	public void sendMessage(String msg) {
		synchronized (mLock){
			if (mWaitSend.length() == 0) {
				mWaitSend = msg;
				mTimerSend.obtainMessage(0).sendToTarget();
			} else {
				mWaitSend = mWaitSend + msg;
			}
		}/*
		mSendQue.add(msg);
		if (mSendQue.size() == 1) {
			mTimerSend.obtainMessage(0).sendToTarget();
		}*/
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		 // TODO Auto-generated method stub
		 mJSRestInterface.onActivityResult(requestCode, resultCode, data);
	 }
}
