/** Automatically generated file. DO NOT MODIFY */
package com.zonesion.web.LightIntensity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}