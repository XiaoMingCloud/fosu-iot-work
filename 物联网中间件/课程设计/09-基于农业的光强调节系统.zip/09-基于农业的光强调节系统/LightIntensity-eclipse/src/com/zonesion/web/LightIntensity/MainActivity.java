package com.zonesion.web.LightIntensity;

import com.zonesion.util.js.JSRestInterface;
import com.zonesion.web.LightIntensity.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

@SuppressLint("NewApi")
public class MainActivity extends Activity {

	WebView mWebView;
	private Handler mHandler = new Handler();
	
	JSRestInterface mJSRestInterface;
	
    @SuppressLint("NewApi")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//ȥ�������� 
        setContentView(R.layout.activity_main);
   	 	
   		mWebView = (WebView) findViewById(R.id.webView);
   		mWebView.getSettings().setDefaultTextEncodingName("UTF-8") ;
   		mWebView.getSettings().setJavaScriptEnabled(true);
   		mWebView.getSettings().setUseWideViewPort(true); 
   		mWebView.getSettings().setLoadWithOverviewMode(true);
   		mWebView.getSettings().setDomStorageEnabled(true);     
   		mWebView.setWebViewClient(new WebViewClient(){       
               public boolean shouldOverrideUrlLoading(WebView view, String url) {       
                   view.loadUrl(url);       
                   return true;        
               }        
   		});
   		mWebView.setWebChromeClient(new WebChromeClient() { 
   			public void onConsoleMessage(String message, int lineNumber, String sourceID) { 
   				Log.d("JScript Log", sourceID+":"+lineNumber+": "+message ); 
   			}
	   		 @Override
	         public void onReceivedTitle(WebView view, String title) {
	   			MainActivity.this.setTitle(title);//a textview
	         }
   		});
   		
   		
   		mJSRestInterface = new JSRestInterface(this, mWebView, mHandler);
   		
   		mWebView.addJavascriptInterface(mJSRestInterface, "droid");
   		
        mWebView.loadUrl("file:///android_asset/index.html");
        
    }
    
    @SuppressLint("NewApi")
	public void onResume(){
    	super.onResume();
    }
    
    @SuppressLint("NewApi")
	public void onPause() {
    	super.onPause();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if(keyCode == KeyEvent.KEYCODE_BACK) {
        	callJS("getback", "");
        	return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    
	@SuppressLint("NewApi")
	private void callJS(String fun, String args) {

		final String s = "javascript:" + fun + "(" + args + ")";

		mHandler.post(new Runnable() {
			public void run() {

				mWebView.loadUrl(s);
			}
		});
	}
    
    public void onDestroy(){
    	super.onDestroy();
    	System.exit(0);
    }
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		 // TODO Auto-generated method stub
		 mJSRestInterface.onActivityResult(requestCode, resultCode, data);
	 }
}
