/**
 * Created by zonesion on 2017/9/21.
 */
var config={
    'id':'9262873964',
    'key':'GRpU3RCs4KZIQPGNR5iUbRznAXhs36z7',
    'server':'10.130.8.247'
}









