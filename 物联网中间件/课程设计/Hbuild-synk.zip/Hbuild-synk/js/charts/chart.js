$(function () {
    dial('illum','Lx', 2300);
    thermometer('temp','℃','#ff7850', -20, 80, 0);
    thermometer('humi','%','#27A9E3', 0, 100, 0);
});

function lightDisplay(value) {
    dial('illum','Lx', value);
}

// 表盘
function dial(id, unit, value) {
    var csatGauge = new FusionCharts({
        'type': 'angulargauge',
        'renderAt': id,
        'width': '100%',
        'height': '100%',
        'dataFormat': 'json',
        'dataSource': {
            'chart': {
                'lowerLimit': '0',
                'upperLimit': '5000',
                'lowerLimitDisplay': 'Low',
                'upperLimitDisplay': 'High',
                'numbersuffix': unit,
                'showValue': '1',
                'valueBelowPivot': '1',
                'bgcolor': '#ffffff',
                'theme': 'fint'
            },
            'colorrange': {
                'color': [
                    {
                        'minValue': '0',
                        'maxValue': '3000',
                        'code': '#80e3c8'
                    },
                    {
                        'minValue': '3000',
                        'maxValue': '4500',
                        'code': '#86c4df'
                    },
                    {
                        'minValue': '4500',
                        'maxValue': '5000',
                        'code': '#ffb9a4'
                    }
                ]
            },
            'dials': {
                'dial': [
                    {
                        'value': value
                    }
                ]
            }
        }
    });

    csatGauge.render();
};

//温度显示
function temperDisplay(value){
    thermometer('temp','℃','#ff7850', -20, 80, value);
}
//显示湿度
function humidityDisplay(value){
    thermometer('humi','%','#27A9E3', 0, 100, value);
}

// 温度计绘制
function thermometer(id,unit,color, min, max, value) {
    var csatGauge = new FusionCharts({
        'type': 'thermometer',
        'renderAt': id,
        'width': '100%',
        'height': '100%',
        'dataFormat': 'json',
        'dataSource': {
            'chart': {
                'upperLimit': max,
                'lowerLimit': min,
                'numberSuffix': unit,
                'decimals': '1',
                'showhovereffect': '1',
                'gaugeFillColor': color,
                'gaugeBorderColor': '#008ee4',
                'showborder': '0',
                'tickmarkgap': '5',
                'theme': 'fint'
            },
            'value': value
        }
    });
    csatGauge.render();
};
// 曲线
function curve(id,unit,color) {
    var revenueChart = new FusionCharts({
        "type": "area2d",
        "renderAt": id,
        "width": "100%",
        "height": "400",
        "dataFormat": "json",
        "dataSource":  {
            "chart": {
                "numbersuffix": unit,
                "showborder": "0",
                "showvalues": "0",
                "paletteColors": color,
                "plotFillAlpha": "30",
                "theme": "fint"
            },
            "data": [
                {
                    "label": "0:00",
                    "value": "15.0",
                    "tooltext": "0:00{br}15.0V"
                },
                {
                    "label": "1:00",
                    "value": "13.0",
                    "tooltext": "1:00{br}13.0V"
                },
                {
                    "label": "12:00",
                    "value": "10.0",
                    "tooltext": "12:00{br}10.0V"
                },
                {
                    "label": "0:00",
                    "value": "15.0",
                    "tooltext": "0:00{br}15.0V"
                },
                {
                    "label": "1:00",
                    "value": "13.0",
                    "tooltext": "1:00{br}13.0V"
                },
                {
                    "label": "2:00",
                    "value": "10.0",
                    "tooltext": "12:00{br}10.0V"
                },
                {
                    "label": "0:00",
                    "value": "15.0",
                    "tooltext": "0:00{br}15.0V"
                },
                {
                    "label": "11:00",
                    "value": "13.0",
                    "tooltext": "1:00{br}13.0V"
                },
                {
                    "label": "2:00",
                    "value": "10.0",
                    "tooltext": "12:00{br}10.0V"
                },
                {
                    "label": "0:00",
                    "value": "15.0",
                    "tooltext": "0:00{br}15.0V"
                },
                {
                    "label": "1:00",
                    "value": "13.0",
                    "tooltext": "1:00{br}13.0V"
                },
                {
                    "label": "2:00",
                    "value": "10.0",
                    "tooltext": "12:00{br}10.0V"
                }
            ]
        }
    });
    revenueChart.render();
};
