package cn.edu.fosu.liujiaming;



import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.connection.stream.ObjectRecord;
import org.springframework.data.redis.connection.stream.RecordId;
import org.springframework.data.redis.connection.stream.StreamRecords;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class HmDianPingApplicationTests {
    @Autowired
    RedisTemplate redisTemplate;


    @Test
    public  void main() {
        Map<String, String> message = new HashMap<>();
        MapRecord<String ,String,String> record = StreamRecords.newRecord()
                .in("stream.orders")
                .ofMap(message)
                .withId(RecordId.autoGenerate());
        redisTemplate.opsForStream().add(record);
    }
}