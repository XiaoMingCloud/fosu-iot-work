package com.example.text.ui.main;

import android.os.Bundle;

interface MainActivity {
    void onCreate(Bundle savedInstanceState);
}
